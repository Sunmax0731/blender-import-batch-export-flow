# AGENTS

この repo は `blender-import-batch-export-flow` の closed alpha 実装単位です。

## Scope

- Root: `D:\AI\BlenderAddon\blender-import-batch-export-flow`
- Domain: BlenderAddon
- Product kind: blender-addon
- Source pack: `D:/AI/BlenderAddon/created_idea_003_blender-import-batch-export-flow/idea_003_blender-import-batch-export-flow.zip`
- Public repo: `https://github.com/Sunmax0731/blender-import-batch-export-flow`

## Working Rules

- README、AGENTS、SKILL、docs を同じ変更単位で更新する。
- created_idea は `D:/AI/BlenderAddon/created_idea_003_blender-import-batch-export-flow` を正とし、同梱 ZIP の `metadata.json` と repo 名が一致することを確認する。
- ZIPサイズや生成時刻のように揺れる値を QCDS の固定評価根拠にしない。
- mojibake 判定は `npm test` 内の `scripts/check-mojibake.js` で行う。
- 手動テストは Codex では実施しない。未実施項目を docs に残して release notes にも転記する。
- 作業ブランチは `codex/closed-alpha-release` の1本だけを使い、完了後にローカル/リモートから削除する。

